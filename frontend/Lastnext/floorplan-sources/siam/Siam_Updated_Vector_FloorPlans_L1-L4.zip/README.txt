Siam updated source floor plans — L1 to L4
This export is TRUE VECTOR from newly supplied Master Plan L1-L4(1).pdf.
PDF pages and SVGs were cropped to remove external sheet metadata; some interior grid / dimensions remain to preserve critical architectural geometry.
SVGs are NOT interactive and contain no verified room polygons.
L4 is a distinct 4xx floor plan in this new version.
Room 1313 (ID 146) excluded from future interactive mapping per user instruction, NOT removed from architectural drawing or database.
Do not integrate, commit or deploy without further verification.
